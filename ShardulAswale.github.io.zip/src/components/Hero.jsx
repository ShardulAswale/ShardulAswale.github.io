// Hero.jsx
export const Hero = () => <div>Hero</div>;