// Contact.jsx
export const Contact = () => <div>Contact</div>;