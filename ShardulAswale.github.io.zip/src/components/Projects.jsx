// Projects.jsx
export const Projects = () => <div>Projects</div>;